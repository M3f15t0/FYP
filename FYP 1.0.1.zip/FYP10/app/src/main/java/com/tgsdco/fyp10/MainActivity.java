package com.tgsdco.fyp10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView cropList;
    String[] plants = new String[]{"Tomato","Onion","Carrot","Pepper", "Dill","Basil", "Oregano", "Mint", "Broad beans", "Potato", "Cabbage", "Gherkins", "Cucumber","Chili", "Strawberries" };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cropList= findViewById(R.id.cropsList_lv);

        ArrayAdapter<String> cropsAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,plants);
        cropList.setAdapter(cropsAdapter);
        cropList.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String plants = parent.getItemAtPosition(position).toString();
        Toast.makeText(getApplicationContext(), "Clicked"+ plants, Toast.LENGTH_SHORT ).show();
    }
}
